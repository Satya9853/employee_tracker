from django.contrib import admin
from django.urls import path
from core import views  # Import views directly for redirection

urlpatterns = [
    path('', views.login_view, name='home'),  # 👈 Redirect root to login page
    path('admin/', admin.site.urls),
    path('login/', views.login_view, name='login'),
    path('signup/', views.signup, name='signup'),
    path('dashboard/', views.dashboard, name='dashboard'),
    path('logout/', views.logout_view, name='logout'),
    path('add_ticket/', views.add_ticket, name='add_ticket'),
    path('update_ticket_status/<int:ticket_id>/', views.update_ticket_status, name='update_ticket_status'),
    path('forgot-password/', views.forgot_password, name='forgot_password'),
]
