# core/signals.py
from django.db.models.signals import post_migrate
from django.dispatch import receiver
from .models import TicketStatus

@receiver(post_migrate)

@receiver(post_migrate)
def create_default_ticket_statuses(sender, **kwargs):
    for status in ['IN PROGRESS', 'COMPLETED']:
        TicketStatus.objects.get_or_create(name=status)