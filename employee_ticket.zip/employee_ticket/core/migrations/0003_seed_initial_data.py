from django.db import migrations

def seed_initial_data(apps, schema_editor):
    TicketStatus = apps.get_model('core', 'TicketStatus')
    CurrentRole = apps.get_model('core', 'CurrentRole')

    TicketStatus.objects.bulk_create([
        TicketStatus(id=1, name="open"),
        TicketStatus(id=2, name="in progress"),
        TicketStatus(id=3, name="completed")
    ])

    CurrentRole.objects.bulk_create([
        CurrentRole(id=1, name="employee"),
        CurrentRole(id=2, name="manager")
    ])

class Migration(migrations.Migration):

    dependencies = [
        ('core', '0002_currentrole_ticketstatus_and_more'),  # Change this to match actual filename of the one before this
    ]

    operations = [
        migrations.RunPython(seed_initial_data),
    ]
