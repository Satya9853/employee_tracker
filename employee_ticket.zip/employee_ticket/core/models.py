from django.db import models
from django.contrib.auth.models import AbstractBaseUser, PermissionsMixin, BaseUserManager
from django.utils import timezone

class EmployeeManager(BaseUserManager):
    def create_user(self, email, empid, name, password=None, **extra_fields):
        if not email:
            raise ValueError("Email must be provided")
        if not empid:
            raise ValueError("Employee ID must be provided")
        email = self.normalize_email(email)
        user = self.model(email=email, empid=empid, name=name, **extra_fields)
        user.set_password(password)
        user.save(using=self._db)
        return user

    def create_superuser(self, email, empid, name, password=None, **extra_fields):
        extra_fields.setdefault('is_staff', True)
        extra_fields.setdefault('is_superuser', True)
        if extra_fields.get('is_staff') is not True:
            raise ValueError("Superuser must have is_staff=True")
        if extra_fields.get('is_superuser') is not True:
            raise ValueError("Superuser must have is_superuser=True")
        return self.create_user(email, empid, name, password, **extra_fields)


class CurrentRole(models.Model):
    id = models.AutoField(primary_key=True)
    name = models.CharField(max_length=20, unique=True)

    def __str__(self):
        return self.name



class Employee(AbstractBaseUser, PermissionsMixin):
    employee_id = models.CharField(max_length=20, primary_key=True)
    name = models.CharField(max_length=100)
    email = models.EmailField(unique=True)

    reporting_manager = models.ForeignKey(
        'self',
        null=True,
        blank=True,
        on_delete=models.SET_NULL,
        related_name='reportees'
    )

    shift = models.CharField(max_length=10, choices=[('1', 'Shift 1'), ('2', 'Shift 2')])
    current_role = models.ForeignKey(CurrentRole, on_delete=models.PROTECT)
    work_time = models.FloatField(default=0)

    is_staff = models.BooleanField(default=False)
    is_active = models.BooleanField(default=True)

    created_at = models.DateTimeField(default=timezone.now)
    updated_at = models.DateTimeField(auto_now=True)

    USERNAME_FIELD = 'email'
    REQUIRED_FIELDS = ['employee_id', 'name']

    objects = EmployeeManager()

    def __str__(self):
        return f"{self.name} ({self.email})"


class TicketStatus(models.Model):
    id = models.AutoField(primary_key=True)
    name = models.CharField(max_length=20, unique=True)
    status_id = models.IntegerField(unique=True)  # Add this line

    def __str__(self):
        return self.name

class Ticket(models.Model):
    ticket_number = models.CharField(max_length=50)
    ticket_severity = models.CharField(max_length=10, choices=[
        ('low', 'Low'), ('medium', 'Medium'), ('high', 'High')
    ])
    ticket_title = models.CharField(max_length=200)

    reporting_to = models.ForeignKey(
        Employee,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name='assigned_tickets'
    )

    time_taken_to_resolve = models.FloatField(null=True, blank=True)
    status = models.ForeignKey(TicketStatus, on_delete=models.PROTECT)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    in_progress_time = models.DateTimeField(null=True, blank=True)
    employee = models.ForeignKey(Employee, on_delete=models.CASCADE, related_name='tickets')

    def save(self, *args, **kwargs):
        now = timezone.now()

        if self.status.status_id == 1 and not self.in_progress_time:
            self.in_progress_time = now

        if self.status.status_id == 3:
            if not self.in_progress_time:
                # Set in_progress_time now if skipped IN PROGRESS
                self.in_progress_time = now
            if not self.time_taken_to_resolve:
                delta = now - self.in_progress_time
                self.time_taken_to_resolve = delta.total_seconds() / 3600

        super().save(*args, **kwargs)

    def __str__(self):
        return f"{self.ticket_number} - {self.ticket_title}"

