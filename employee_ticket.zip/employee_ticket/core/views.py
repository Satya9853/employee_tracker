import json

from django.utils import timezone
from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.models import User
from django.contrib.auth import authenticate, login as auth_login
from django.contrib.auth import logout
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.contrib.auth.hashers import make_password
from .models import Employee, Ticket
from .forms import TicketForm
from .models import CurrentRole  # Make sure this is imported at the top
from .models import TicketStatus
from django.utils.timezone import localdate
from django.db.models import Q
import datetime
from django.db.models import Count
from django.db.models.functions import TruncDate
from .models import Ticket, TicketStatus
from .forms import TicketForm
from django.core.serializers.json import DjangoJSONEncoder

# Signup view
def signup(request):
    if request.method == 'POST':
        employee_id = request.POST.get('employee_id')
        name = request.POST.get('name')
        email = request.POST.get('email')
        password = request.POST.get('password')
        reporting_manager_id = request.POST.get('reporting_manager')  # This will be ID of Employee
        shift = request.POST.get('shift')
        role_name = request.POST.get('current_role').lower()
        try:
            current_role = CurrentRole.objects.get(name__iexact=role_name)
        except CurrentRole.DoesNotExist:
            messages.error(request, "Invalid role selected.")
            return redirect('signup')
        if Employee.objects.filter(employee_id=employee_id).exists():
            messages.error(request, "Employee ID already exists")
        elif Employee.objects.filter(email=email).exists():
            messages.error(request, "Email already registered")
        else:
            reporting_manager = None
            if reporting_manager_id:
                try:
                    reporting_manager = Employee.objects.get(id=reporting_manager_id)
                except Employee.DoesNotExist:
                    messages.error(request, "Selected reporting manager does not exist.")
                    return redirect('signup')

            user = Employee.objects.create(
                employee_id=employee_id,
                name=name,
                email=email,
                password=make_password(password),
                reporting_manager=reporting_manager,
                shift=shift,
                current_role=current_role,
                work_time=9
            )
            messages.success(request, "Signup successful. Please login.")
            return redirect('login')

    # Pass only manager users to the form dropdown
    managers = Employee.objects.filter(current_role__name='manager')
    return render(request, 'core/signup.html', {'managers': managers})

# Login view (employee_id or email)
def login_view(request):
    if request.method == 'POST':
        identifier = request.POST['identifier']
        password = request.POST['password']

        try:
            user = Employee.objects.get(employee_id=identifier)
        except Employee.DoesNotExist:
            try:
                user = Employee.objects.get(email=identifier)
            except Employee.DoesNotExist:
                user = None

        if user and user.check_password(password):
            auth_login(request, user)
            return redirect('dashboard')
        else:
            messages.error(request, "Invalid credentials")

    return render(request, 'core/login.html')

# Forgot password
def forgot_password(request):
    if request.method == 'POST':
        emp_id = request.POST['employee_id']
        new_pass = request.POST['new_password']
        confirm_pass = request.POST['confirm_password']

        if new_pass != confirm_pass:
            messages.error(request, "Passwords do not match")
        else:
            try:
                user = Employee.objects.get(employee_id=emp_id)
                user.password = make_password(new_pass)
                user.save()
                messages.success(request, "Password updated successfully")
                return redirect('login')
            except Employee.DoesNotExist:
                messages.error(request, "Employee ID not found")

    return render(request, 'core/forgot_password.html')

# Dashboard
@login_required
def dashboard(request):
    employee = request.user
    tickets = Ticket.objects.filter(employee=employee)
    form = TicketForm()

    # Completed and Pending Tickets
    completed_status = TicketStatus.objects.filter(name__iexact='completed').first()
    completed_count = tickets.filter(status=completed_status).count() if completed_status else 0
    pending_count = tickets.exclude(status=completed_status).count() if completed_status else tickets.count()

    # Work time calculation
    total_work_time = sum(t.time_taken_to_resolve or 0 for t in tickets.filter(status=completed_status)) if completed_status else 0
    idle_time = round(max(9 - total_work_time, 0), 2)

    # Weekly chart data (last 7 days, only completed)
    today = localdate()
    week_ago = today - datetime.timedelta(days=6)
    date_range = (week_ago, today)

    stats = (
        tickets.filter(status=completed_status, created_at__date__range=date_range)
               .annotate(date=TruncDate('created_at'))
               .values('date')
               .annotate(count=Count('id'))
               .order_by('date')
    )

    # Labels and chart data for last 7 days
    labels = [(week_ago + datetime.timedelta(days=i)).strftime('%b %d') for i in range(7)]
    stat_map = {st['date']: st['count'] for st in stats}
    chart_data = [stat_map.get(week_ago + datetime.timedelta(days=i), 0) for i in range(7)]

    # Tickets per day JSON (all statuses, all time)
    tickets_per_day = (
        tickets.annotate(day=TruncDate('created_at'))
               .values('day')
               .annotate(count=Count('id'))
               .order_by('day')
    )
    tickets_per_day_dict = {str(t['day']): t['count'] for t in tickets_per_day}
    tickets_per_day_json = json.dumps(tickets_per_day_dict, cls=DjangoJSONEncoder)

    context = {
        'employee': employee,
        'tickets': tickets,
        'form': form,
        'total_work_time': round(total_work_time, 2),
        'idle_time': idle_time,
        'completed_count': completed_count,
        'pending_count': pending_count,
        'chart_labels': labels,
        'chart_data': chart_data,
        'tickets_per_day_json': tickets_per_day_json,
    }

    return render(request, 'core/dashboard.html', context)# Add ticket
@login_required
def add_ticket(request):
    if request.method == 'POST':
        form = TicketForm(request.POST)
        if form.is_valid():
            ticket = form.save(commit=False)

            try:
                employee = request.user
                ticket.employee = employee
            except Employee.DoesNotExist:
                messages.error(request, "Employee record not found.")
                return redirect('dashboard')

            # # ✅ Optional reporting manager assignment
            # manager = employee.reporting_manager
            # if manager and manager != employee:
            #     ticket.reporting_to = manager
            # else:
            #     ticket.reporting_to = None  # Optional fallback

            # ✅ Assign TicketStatus safely
            print("Selected Reporting Manager:", ticket.reporting_to)
            try:
                ticket.status = TicketStatus.objects.get(status_id=2)  # or name__iexact='OPEN'
            except TicketStatus.DoesNotExist:
                messages.error(request, "Ticket status 'OPEN' not found.")
                return redirect('dashboard')

            ticket.save()
            messages.success(request, 'Ticket added successfully!')
        else:
            messages.error(request, 'There was an error with your submission.')

    return redirect('dashboard')


# Update ticket status
@login_required
def update_ticket_status(request, ticket_id):
    if request.method == 'POST':
        employee = get_object_or_404(Employee, email=request.user.email)
        ticket = get_object_or_404(Ticket, id=ticket_id, employee=employee)

        status_id = request.POST.get('status_id')

        if status_id in ['1', '2', '3']:
            new_status = get_object_or_404(TicketStatus, status_id=int(status_id))

            if int(status_id) == 1:  # In Progress
                if not ticket.in_progress_time:
                    ticket.in_progress_time = timezone.now()

            elif int(status_id) == 3:  # Completed
                if not ticket.in_progress_time:
                    # Optional fallback if user skipped In Progress step
                    ticket.in_progress_time = timezone.now()
                    ticket.time_taken = 0.0
                else:
                    time_diff = timezone.now() - ticket.in_progress_time
                    ticket.time_taken = round(time_diff.total_seconds() / 3600, 2)

            ticket.status = new_status
            ticket.save()

    return redirect('dashboard')


# Logout
def logout_view(request):
    logout(request)
    return redirect('login')
