from django import forms
from django.contrib.auth.forms import UserCreationForm, AuthenticationForm
from .models import Employee, Ticket
from .models import CurrentRole  # Make sure this import is at the top

# core/forms.py
from django import forms
from django.contrib.auth.forms import UserCreationForm
from .models import Employee

class EmployeeCreationForm(UserCreationForm):
    class Meta:
        model = Employee
        fields = (
            'employee_id',
            'name',
            'email',
            'password1',
            'password2',
            'reporting_manager',
            'shift',
            'current_role',
        )

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields['reporting_manager'].queryset = Employee.objects.filter(current_role__name='manager')
        self.fields['reporting_manager'].label = "Reporting Manager"
        for field in self.fields.values():
            field.widget.attrs.update({
                'class': 'w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-400'
            })


class EmployeeAuthenticationForm(AuthenticationForm):
    class Meta:
        model = Employee
        fields = ('email', 'password')


class TicketForm(forms.ModelForm):
    class Meta:
        model = Ticket
        fields = ('ticket_number', 'ticket_severity', 'ticket_title', 'reporting_to')

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

        # Make 'reporting_to' optional
        self.fields['reporting_to'].required = False
        self.fields['reporting_to'].widget.attrs['required'] = False

        # Limit queryset to only employees with 'manager' role
        try:
            manager_role = CurrentRole.objects.get(name__iexact='manager')
            self.fields['reporting_to'].queryset = Employee.objects.filter(current_role=manager_role)
        except CurrentRole.DoesNotExist:
            self.fields['reporting_to'].queryset = Employee.objects.none()

        self.fields['reporting_to'].label = "Reporting Manager"
        self.fields['reporting_to'].widget.attrs.update({
            'class': 'form-select mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:ring-blue-500 focus:border-blue-500 sm:text-sm'
        })
